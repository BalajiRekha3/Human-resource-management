package com.example.hr.management.service.impl;

import com.example.hr.management.service.PayrollService;
import org.springframework.stereotype.Service;

@Service
public class PayrollServiceImpl implements PayrollService {
}
