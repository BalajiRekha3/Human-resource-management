package com.example.hr.management.controller;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class PayrollController {
}
