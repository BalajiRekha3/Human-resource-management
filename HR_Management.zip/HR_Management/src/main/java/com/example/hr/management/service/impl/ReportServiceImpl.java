package com.example.hr.management.service.impl;

import com.example.hr.management.service.ReportService;
import org.springframework.stereotype.Service;

@Service
public class ReportServiceImpl implements ReportService {
}
