package com.example.hr.management.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Payroll {
    @Id
    private Long id;
}
