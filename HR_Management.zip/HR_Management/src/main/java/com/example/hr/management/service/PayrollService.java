package com.example.hr.management.service;

public interface PayrollService {
}
