package com.example.hr.management.dto;

public class AttendanceDTO {
}
