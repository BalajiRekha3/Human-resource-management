package com.example.hr.management.repository;

import org.springframework.stereotype.Repository;

@Repository
public interface PayrollRepository {
}
