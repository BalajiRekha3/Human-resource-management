package com.example.hr.management.util;

import org.springframework.stereotype.Component;

@Component
public class SalaryCalculator {
}
